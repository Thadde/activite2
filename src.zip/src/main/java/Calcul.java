package Appli;

public class Calcul {
/** Calcul la somme de deux nombres **/
public static int somme(int a,int b){
return a+b;
}
public static int maFonction(int a, int b) {
if (b >= 10) {
return a/b;
}
return b;
}
/**
* @return a / b si b != 0
* @throw IllegalArgumentException si b == 0
*/
public static int division(int a,int b){
if ( b == 0 ) {
throw new IllegalArgumentException("b ne doit pas etre 0");
}
return a / b;
}
}